# cb-hackathon-covid19

This is a backend built for the portal to visualize the COVID19 - 2020 Count of the Victims in India 
