package com.cb.covid.pojo;

import java.util.List;

public class CovidCasesCount {

	private List<StateWiseCovidCases> stateWiseCovidCasesList;

	public List<StateWiseCovidCases> getStateWiseCovidCasesList() {
		return stateWiseCovidCasesList;
	}

}
