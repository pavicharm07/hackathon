package com.cb.covid;

import org.junit.jupiter.api.Test;

public class Covid19InfectedCasesApplicationTests {
	   @Test
	   public void main() {
		   Covid19InfectedCasesApplication.main(new String[] {});
	   }
	}
